# The Cube

A Pen created on CodePen.io. Original URL: [https://codepen.io/ichtestenurmal/pen/YzJyZvo](https://codepen.io/ichtestenurmal/pen/YzJyZvo).

See if you can solve this classic Rubik's puzzle game made in three.js.